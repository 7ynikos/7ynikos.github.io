---
layout: post
title:  "joining thinkpad gang"
date:   2025-11-11
tags: linux
---

Yes, I have fallen for the infamous thinkpad meme and thinking to buy one. 

Initially, I had no thought of purchasing linux hardware as opposed to a general laptop but as I delved deeper into the dark alleys of linux chads, distrohopping addicts and vrms bots, I started feeling the need to get a dedicated linux machine that is meant for it (yeah, I have another laptop using full blown linux (arch btw)). I initially had the idea of buying a used thinkpad and then upgrading it but after reading the reviews of refurbished and renewed laptops along with the lack of thinkpad parts in India, I dumped that idea. After days of deliberate thought, I finally decided to buy a Thinkpad T480, the last great thinkpad. I'll order it by next year, I don't really need something for coding right now, but i will in the future so yeah.
