---
layout: post
title: vibe check
date: 2021-06-13
tags: random

imageurl: https://source.unsplash.com/QonMStIYe74/300x300
imagealt: vibe
imagecaption: indian summer is here
---

Since my graduation from college, I have learnt a lot, the lockdown of 2020 and 2021 have given me some time to reflect on what my priorites should be and how I should fit into this world. I look back and think about how I could have utilized my time at college better. But then again, humans are greedy and even in terms of my time, I would want to squeeze in tasks in every small gap, therefore, I like to imagine that *maybe* I turned out just *fine*. 

{% include image.html %}

I have begun to understand how important a person's environment and peer group is, in influencing his/her interests and productivity. I am glad to have realized this and wish to create a healthier environment for myself. I look at other people's profile on sites like linkedin, github and twitter, to find myself lacking in many areas but I don't lose heart by doing so, I instead believe that it kindles the competitive spirit within me and gives me some temporary immunity against procrastination (interesting description, eh?).

Another interesting thing that I have realized is that I need to focus more on personal branding, I have set up my [blog](https://rustyelectron.live), online resume, revived my youtube channel and started tidying up my github repos. I also realized that reddit is a great place for discovering blogs, ideas and finding guidance from strangers and so I plan to hang out more often in some 'productive' subreddits.

Overall, no I am not depressed and yes I think I am glad about how far I have come but I am absolutely sure that I have a lot to learn and explore and boy, I need to pick up some pace.