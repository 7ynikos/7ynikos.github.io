i own a computer, and i have made a blog.
